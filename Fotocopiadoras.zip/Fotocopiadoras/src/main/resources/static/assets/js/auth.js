// Authentication utilities
function isAuthenticated() {
    return localStorage.getItem('token') !== null;
}

function getToken() {
    return localStorage.getItem('token');
}

function getUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'index.html';
}

// Proteger páginas del dashboard
function requireAuth() {
    if (!isAuthenticated()) {
        window.location.href = 'index.html';
    }
}

// Cargar información del usuario en el dashboard
function loadUserInfo() {
    const user = getUser();
    if (user) {
        const usernameEl = document.querySelector('.username');
        const rolEl = document.querySelector('.user-role');
        
        if (usernameEl) usernameEl.textContent = user.username;
        if (rolEl) rolEl.textContent = user.rol;
    }
}

// Initializar dashboard
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.layout')) {
        requireAuth();
        loadUserInfo();
        
        // Logout button
        const logoutBtn = document.querySelector('.logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', logout);
        }
    }
});
