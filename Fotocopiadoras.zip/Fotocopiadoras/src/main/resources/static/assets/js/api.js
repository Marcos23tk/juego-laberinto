// API Configuration
const API_BASE_URL = 'http://localhost:8080/api/v1';

// Make API calls
async function apiCall(method, endpoint, data = null) {
    const token = localStorage.getItem('token');
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const config = {
        method: method,
        headers: headers
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
        config.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(API_BASE_URL + endpoint, config);
        
        if (response.status === 401) {
            // Token inválido o expirado
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = 'index.html';
            return null;
        }
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || 'Error en la solicitud');
        }
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Entity APIs
const entityAPI = {
    clasificacion: {
        list: () => apiCall('GET', '/clasificacion'),
        get: (id) => apiCall('GET', `/clasificacion/${id}`),
        create: (data) => apiCall('POST', '/clasificacion', data),
        update: (id, data) => apiCall('PUT', `/clasificacion/${id}`, data),
        delete: (id) => apiCall('DELETE', `/clasificacion/${id}`)
    },
    
    marca: {
        list: () => apiCall('GET', '/marca'),
        get: (id) => apiCall('GET', `/marca/${id}`),
        create: (data) => apiCall('POST', '/marca', data),
        update: (id, data) => apiCall('PUT', `/marca/${id}`, data),
        delete: (id) => apiCall('DELETE', `/marca/${id}`)
    },
    
    modelo: {
        list: () => apiCall('GET', '/modelo'),
        get: (id) => apiCall('GET', `/modelo/${id}`),
        create: (data) => apiCall('POST', '/modelo', data),
        update: (id, data) => apiCall('PUT', `/modelo/${id}`, data),
        delete: (id) => apiCall('DELETE', `/modelo/${id}`)
    },
    
    equipo: {
        list: () => apiCall('GET', '/equipo'),
        get: (id) => apiCall('GET', `/equipo/${id}`),
        create: (data) => apiCall('POST', '/equipo', data),
        update: (id, data) => apiCall('PUT', `/equipo/${id}`, data),
        delete: (id) => apiCall('DELETE', `/equipo/${id}`)
    },
    
    usuario: {
        list: () => apiCall('GET', '/usuario'),
        get: (id) => apiCall('GET', `/usuario/${id}`),
        create: (data) => apiCall('POST', '/usuario', data),
        update: (id, data) => apiCall('PUT', `/usuario/${id}`, data),
        delete: (id) => apiCall('DELETE', `/usuario/${id}`)
    },
    
    rol: {
        list: () => apiCall('GET', '/rol'),
        get: (id) => apiCall('GET', `/rol/${id}`),
        create: (data) => apiCall('POST', '/rol', data),
        update: (id, data) => apiCall('PUT', `/rol/{id}`, data),
        delete: (id) => apiCall('DELETE', `/rol/${id}`)
    },
    
    sede: {
        list: () => apiCall('GET', '/sede'),
        get: (id) => apiCall('GET', `/sede/${id}`),
        create: (data) => apiCall('POST', '/sede', data),
        update: (id, data) => apiCall('PUT', `/sede/${id}`, data),
        delete: (id) => apiCall('DELETE', `/sede/${id}`)
    },
    
    personal: {
        list: () => apiCall('GET', '/personal'),
        get: (id) => apiCall('GET', `/personal/${id}`),
        create: (data) => apiCall('POST', '/personal', data),
        update: (id, data) => apiCall('PUT', `/personal/${id}`, data),
        delete: (id) => apiCall('DELETE', `/personal/${id}`)
    }
};

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES');
}

function showMessage(message, type = 'success') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.main-content') || document.body;
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => alertDiv.remove(), 3000);
}

function showError(error) {
    showMessage(error.message || 'Ocurrió un error', 'error');
}
