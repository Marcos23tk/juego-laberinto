// Main Dashboard functionality
let currentModule = 'dashboard';
let currentData = [];
let editingId = null;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    requireAuth();
    loadUserInfo();
    setupMenuListeners();
    setupModalListeners();
    loadDashboard();
});

function setupMenuListeners() {
    document.querySelectorAll('.menu-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.classList.contains('logout-btn')) return;
            e.preventDefault();
            
            document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            const module = this.getAttribute('data-module');
            if (module) loadModule(module);
        });
    });
}

function setupModalListeners() {
    const modal = document.getElementById('modal');
    const closeBtn = document.querySelector('.modal-close');
    
    closeBtn.addEventListener('click', () => closeModal());
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });
}

async function loadModule(module) {
    currentModule = module;
    document.getElementById('pageTitle').textContent = getModuleTitle(module);
    
    switch(module) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'equipos':
            loadEquipos();
            break;
        case 'usuarios':
            loadUsuarios();
            break;
        case 'sedes':
            loadSedes();
            break;
        case 'personal':
            loadPersonal();
            break;
        case 'marcas':
            loadMarcas();
            break;
        case 'roles':
            loadRoles();
            break;
    }
}

function getModuleTitle(module) {
    const titles = {
        'dashboard': '📊 Dashboard',
        'equipos': '🖨️ Equipos',
        'usuarios': '👥 Usuarios',
        'sedes': '🏢 Sedes',
        'personal': '👨‍💼 Personal',
        'marcas': '🏷️ Marcas',
        'roles': '🔑 Roles'
    };
    return titles[module] || module;
}

// Dashboard
async function loadDashboard() {
    const content = document.getElementById('content');
    try {
        const equipos = await entityAPI.equipo.list();
        const usuarios = await entityAPI.usuario.list();
        const sedes = await entityAPI.sede.list();
        
        content.innerHTML = `
            <div class="grid">
                <div class="stat-card">
                    <div class="stat-value">${equipos.data?.length || 0}</div>
                    <div class="stat-label">Equipos Registrados</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${usuarios.data?.length || 0}</div>
                    <div class="stat-label">Usuarios del Sistema</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${sedes.data?.length || 0}</div>
                    <div class="stat-label">Sedes</div>
                </div>
            </div>
            <div class="card">
                <h3 class="card-title">Últimos Equipos Registrados</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Código Patrimonial</th>
                            <th>Descripción</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${equipos.data?.slice(0, 5).map(e => `
                            <tr>
                                <td>${e.codigoPatrimonial}</td>
                                <td>${e.descripcion || '-'}</td>
                                <td>${e.estadoEquipo?.nombre || '-'}</td>
                            </tr>
                        `).join('') || '<tr><td colspan="3" class="text-center">No hay datos</td></tr>'}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Equipos
async function loadEquipos() {
    const content = document.getElementById('content');
    content.innerHTML = `<div class="loading"></div>`;
    
    try {
        const response = await entityAPI.equipo.list();
        currentData = response.data || [];
        
        content.innerHTML = `
            <div class="mb-20">
                <button class="btn btn-primary" onclick="openCreateModal()">+ Nuevo Equipo</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Código Patrimonial</th>
                            <th>Descripción</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${currentData.map(item => `
                            <tr>
                                <td>${item.codigoPatrimonial}</td>
                                <td>${item.descripcion || '-'}</td>
                                <td>${item.modelo?.marca?.nombre || '-'}</td>
                                <td>${item.modelo?.nombre || '-'}</td>
                                <td>${item.estadoEquipo?.nombre || '-'}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn action-edit" onclick="openEditModal(${item.id})">Editar</button>
                                        <button class="action-btn action-delete" onclick="deleteItem(${item.id})">Eliminar</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Usuarios
async function loadUsuarios() {
    const content = document.getElementById('content');
    content.innerHTML = `<div class="loading"></div>`;
    
    try {
        const response = await entityAPI.usuario.list();
        currentData = response.data || [];
        
        content.innerHTML = `
            <div class="mb-20">
                <button class="btn btn-primary" onclick="openCreateModal()">+ Nuevo Usuario</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Usuario</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${currentData.map(item => `
                            <tr>
                                <td>${item.nombre}</td>
                                <td>${item.username}</td>
                                <td>${item.rol?.nombre || '-'}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn action-edit" onclick="openEditModal(${item.id})">Editar</button>
                                        <button class="action-btn action-delete" onclick="deleteItem(${item.id})">Eliminar</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Sedes
async function loadSedes() {
    const content = document.getElementById('content');
    content.innerHTML = `<div class="loading"></div>`;
    
    try {
        const response = await entityAPI.sede.list();
        currentData = response.data || [];
        
        content.innerHTML = `
            <div class="mb-20">
                <button class="btn btn-primary" onclick="openCreateModal()">+ Nueva Sede</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Ubicación</th>
                            <th>Ciudad</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${currentData.map(item => `
                            <tr>
                                <td>${item.nombre}</td>
                                <td>${item.ubicacion || '-'}</td>
                                <td>${item.ciudad || '-'}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn action-edit" onclick="openEditModal(${item.id})">Editar</button>
                                        <button class="action-btn action-delete" onclick="deleteItem(${item.id})">Eliminar</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Personal
async function loadPersonal() {
    const content = document.getElementById('content');
    content.innerHTML = `<div class="loading"></div>`;
    
    try {
        const response = await entityAPI.personal.list();
        currentData = response.data || [];
        
        content.innerHTML = `
            <div class="mb-20">
                <button class="btn btn-primary" onclick="openCreateModal()">+ Nuevo Personal</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Cargo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${currentData.map(item => `
                            <tr>
                                <td>${item.nombre} ${item.apellido}</td>
                                <td>${item.email || '-'}</td>
                                <td>${item.telefono || '-'}</td>
                                <td>${item.cargo || '-'}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn action-edit" onclick="openEditModal(${item.id})">Editar</button>
                                        <button class="action-btn action-delete" onclick="deleteItem(${item.id})">Eliminar</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Marcas
async function loadMarcas() {
    const content = document.getElementById('content');
    content.innerHTML = `<div class="loading"></div>`;
    
    try {
        const response = await entityAPI.marca.list();
        currentData = response.data || [];
        
        content.innerHTML = `
            <div class="mb-20">
                <button class="btn btn-primary" onclick="openCreateModal()">+ Nueva Marca</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${currentData.map(item => `
                            <tr>
                                <td>${item.nombre}</td>
                                <td>${item.descripcion || '-'}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn action-edit" onclick="openEditModal(${item.id})">Editar</button>
                                        <button class="action-btn action-delete" onclick="deleteItem(${item.id})">Eliminar</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Roles
async function loadRoles() {
    const content = document.getElementById('content');
    content.innerHTML = `<div class="loading"></div>`;
    
    try {
        const response = await entityAPI.rol.list();
        currentData = response.data || [];
        
        content.innerHTML = `
            <div class="mb-20">
                <button class="btn btn-primary" onclick="openCreateModal()">+ Nuevo Rol</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${currentData.map(item => `
                            <tr>
                                <td>${item.nombre}</td>
                                <td>${item.descripcion || '-'}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn action-edit" onclick="openEditModal(${item.id})">Editar</button>
                                        <button class="action-btn action-delete" onclick="deleteItem(${item.id})">Eliminar</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        showError(error);
    }
}

// Modal functions
function openCreateModal() {
    editingId = null;
    const modal = document.getElementById('modal');
    document.getElementById('modalTitle').textContent = `Crear nuevo ${getModuleTitle(currentModule).split(' ')[1]}`;
    modal.classList.add('show');
}

function openEditModal(id) {
    editingId = id;
    const modal = document.getElementById('modal');
    document.getElementById('modalTitle').textContent = `Editar ${getModuleTitle(currentModule).split(' ')[1]}`;
    modal.classList.add('show');
}

function closeModal() {
    const modal = document.getElementById('modal');
    modal.classList.remove('show');
    editingId = null;
}

async function deleteItem(id) {
    if (!confirm('¿Está seguro de eliminar este elemento?')) return;
    
    try {
        await entityAPI[currentModule].delete(id);
        showMessage('Elemento eliminado exitosamente');
        loadModule(currentModule);
    } catch (error) {
        showError(error);
    }
}
