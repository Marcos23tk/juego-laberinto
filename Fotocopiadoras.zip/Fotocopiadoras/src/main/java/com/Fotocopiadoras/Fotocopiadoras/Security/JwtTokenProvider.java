package com.Fotocopiadoras.Fotocopiadoras.Security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SecurityException;
import com.Fotocopiadoras.Fotocopiadoras.Config.AppProperties;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtTokenProvider {

    private final AppProperties appProperties;

    public JwtTokenProvider(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(appProperties.getJwtSecret().getBytes());
    }

    @SuppressWarnings("deprecation")
    public String generateToken(String username, Integer userId, String roleName) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + appProperties.getJwtExpirationMs());

        return Jwts.builder()
            .subject(username)
            .claim("userId", userId)
            .claim("role", roleName)
            .issuedAt(now)
            .expiration(expiryDate)
            .signWith(getSigningKey(), SignatureAlgorithm.HS512)
            .compact();
    }

    public String getUsernameFromJWT(String token) {
        Claims claims = Jwts.parser()
            .setSigningKey(getSigningKey())
            .build()
            .parseClaimsJws(token)
            .getBody();

        return claims.getSubject();
    }

    public Integer getUserIdFromJWT(String token) {
        Claims claims = Jwts.parser()
            .setSigningKey(getSigningKey())
            .build()
            .parseClaimsJws(token)
            .getBody();

        Number userId = claims.get("userId", Number.class);
        return userId != null ? userId.intValue() : null;
    }

    public String getRoleFromJWT(String token) {
        Claims claims = Jwts.parser()
            .setSigningKey(getSigningKey())
            .build()
            .parseClaimsJws(token)
            .getBody();

        return claims.get("role", String.class);
    }

    public boolean validateToken(String authToken) {
        try {
            Jwts.parser()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(authToken);
            return true;
        } catch (SecurityException ex) {
            System.err.println("Invalid JWT signature: {}" + ex);
        } catch (MalformedJwtException ex) {
            System.err.println("Invalid JWT token: {}" + ex);
        } catch (ExpiredJwtException ex) {
            System.err.println("Expired JWT token: {}" + ex);
        } catch (UnsupportedJwtException ex) {
            System.err.println("Unsupported JWT token: {}" + ex);
        } catch (IllegalArgumentException ex) {
            System.err.println("JWT claims string is empty: {}" + ex);
        } catch (JwtException ex) {
            System.err.println("JWT validation error: {}" + ex);
        }
        return false;
    }
}
