package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Clasificacion;
import com.Fotocopiadoras.Fotocopiadoras.Service.ClasificacionService;

@RestController
@RequestMapping("/api/v1/clasificacion")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ClasificacionRestController {
    @Autowired
    private ClasificacionService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Clasificacion>> registrar(@RequestBody Clasificacion c) {
        Clasificacion resultado = service.registrar(c);
        return new ResponseEntity<>(
            ApiResponse.success("Clasificación registrada exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Clasificacion>>> listar() {
        List<Clasificacion> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Clasificaciones obtenidas exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Clasificacion>> buscarPorId(@PathVariable Integer id) {
        Clasificacion resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Clasificación obtenida exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Clasificacion>> actualizar(
            @PathVariable Integer id,
            @RequestBody Clasificacion c) {
        c.setId(id);
        Clasificacion resultado = service.actualizar(c);
        return ResponseEntity.ok(
            ApiResponse.success("Clasificación actualizada exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Clasificación eliminada exitosamente", null)
        );
    }

}