package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Usuario;
import com.Fotocopiadoras.Fotocopiadoras.Service.UsuarioService;

@RestController
@RequestMapping("/api/v1/usuario")
@CrossOrigin(origins = "*", maxAge = 3600)
public class UsuarioRestController {

    @Autowired
    private UsuarioService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Usuario>> registrar(@RequestBody Usuario u) {
        Usuario resultado = service.registrar(u);
        return new ResponseEntity<>(
            ApiResponse.success("Usuario registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Usuario>>> listar() {
        List<Usuario> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Usuarios obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Usuario>> buscarPorId(@PathVariable Integer id) {
        Usuario resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Usuario obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Usuario>> actualizar(
            @PathVariable Integer id,
            @RequestBody Usuario u) {
        u.setId(id);
        Usuario resultado = service.actualizar(u);
        return ResponseEntity.ok(
            ApiResponse.success("Usuario actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Usuario eliminado exitosamente", null)
        );
    }
}