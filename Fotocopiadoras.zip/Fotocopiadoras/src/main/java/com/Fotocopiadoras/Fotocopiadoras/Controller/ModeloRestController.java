package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Modelo;
import com.Fotocopiadoras.Fotocopiadoras.Service.ModeloService;

@RestController
@RequestMapping("/api/v1/modelo")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ModeloRestController {

    @Autowired
    private ModeloService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Modelo>> registrar(@RequestBody Modelo m) {
        Modelo resultado = service.registrar(m);
        return new ResponseEntity<>(
            ApiResponse.success("Modelo registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Modelo>>> listar() {
        List<Modelo> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Modelos obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Modelo>> buscarPorId(@PathVariable Integer id) {
        Modelo resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Modelo obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Modelo>> actualizar(
            @PathVariable Integer id,
            @RequestBody Modelo m) {
        m.setId(id);
        Modelo resultado = service.actualizar(m);
        return ResponseEntity.ok(
            ApiResponse.success("Modelo actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Modelo eliminado exitosamente", null)
        );
    }
}