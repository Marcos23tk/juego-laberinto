package com.Fotocopiadoras.Fotocopiadoras.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Dto.LoginRequest;
import com.Fotocopiadoras.Fotocopiadoras.Dto.LoginResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Usuario;
import com.Fotocopiadoras.Fotocopiadoras.Exception.ValidationException;
import com.Fotocopiadoras.Fotocopiadoras.Security.JwtTokenProvider;
import com.Fotocopiadoras.Fotocopiadoras.Service.UsuarioService;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@RequestBody LoginRequest loginRequest) {
        if (loginRequest.getUsername() == null || loginRequest.getUsername().isBlank()) {
            throw new ValidationException("El username es requerido");
        }
        if (loginRequest.getPassword() == null || loginRequest.getPassword().isBlank()) {
            throw new ValidationException("La contraseña es requerida");
        }

        Optional<Usuario> usuarioOpt = usuarioService.buscarPorUsername(loginRequest.getUsername());
        
        if (!usuarioOpt.isPresent()) {
            throw new ValidationException("Credenciales inválidas");
        }

        Usuario usuario = usuarioOpt.get();

        // Verificar contraseña
        if (!passwordEncoder.matches(loginRequest.getPassword(), usuario.getPassword())) {
            throw new ValidationException("Credenciales inválidas");
        }

        // Generar token JWT
        String token = jwtTokenProvider.generateToken(
            usuario.getUsername(),
            usuario.getId(),
            usuario.getRol().getNombre()
        );

        LoginResponse loginResponse = new LoginResponse(
            token,
            usuario.getId(),
            usuario.getUsername(),
            usuario.getNombre(),
            usuario.getRol().getNombre()
        );

        return new ResponseEntity<>(
            ApiResponse.success("Login exitoso", loginResponse),
            HttpStatus.OK
        );
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<Usuario>> register(@RequestBody Usuario usuario) {
        Usuario usuarioRegistrado = usuarioService.registrar(usuario);
        return new ResponseEntity<>(
            ApiResponse.success("Usuario registrado exitosamente", usuarioRegistrado),
            HttpStatus.CREATED
        );
    }

    @GetMapping("/validate")
    public ResponseEntity<ApiResponse<Object>> validateToken(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new ValidationException("Token no proporcionado");
        }

        String token = authHeader.substring(7);
        if (jwtTokenProvider.validateToken(token)) {
            return ResponseEntity.ok(
                ApiResponse.success("Token válido", null)
            );
        }

        throw new ValidationException("Token inválido");
    }
}
