package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Marca;
import com.Fotocopiadoras.Fotocopiadoras.Service.MarcaService;

@RestController
@RequestMapping("/api/v1/marca")
@CrossOrigin(origins = "*", maxAge = 3600)
public class MarcaRestController {
    @Autowired
    private MarcaService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Marca>> registrar(@RequestBody Marca m) {
        Marca resultado = service.registrar(m);
        return new ResponseEntity<>(
            ApiResponse.success("Marca registrada exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Marca>>> listar() {
        List<Marca> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Marcas obtenidas exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Marca>> buscarPorId(@PathVariable Integer id) {
        Marca resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Marca obtenida exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Marca>> actualizar(
            @PathVariable Integer id,
            @RequestBody Marca m) {
        m.setId(id);
        Marca resultado = service.actualizar(m);
        return ResponseEntity.ok(
            ApiResponse.success("Marca actualizada exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Marca eliminada exitosamente", null)
        );
    }
}