package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.DistritoFiscal;
import com.Fotocopiadoras.Fotocopiadoras.Service.DistritoFiscalService;

@RestController
@RequestMapping("/api/v1/distrito-fiscal")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DistritoFiscalRestController {
    @Autowired
    private DistritoFiscalService service;

    @PostMapping
    public ResponseEntity<ApiResponse<DistritoFiscal>> registrar(@RequestBody DistritoFiscal df) {
        DistritoFiscal resultado = service.registrar(df);
        return new ResponseEntity<>(
            ApiResponse.success("Distrito Fiscal registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<DistritoFiscal>>> listar() {
        List<DistritoFiscal> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Distritos Fiscales obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DistritoFiscal>> buscarPorId(@PathVariable Integer id) {
        DistritoFiscal resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Distrito Fiscal obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<DistritoFiscal>> actualizar(
            @PathVariable Integer id,
            @RequestBody DistritoFiscal df) {
        df.setId(id);
        DistritoFiscal resultado = service.actualizar(df);
        return ResponseEntity.ok(
            ApiResponse.success("Distrito Fiscal actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Distrito Fiscal eliminado exitosamente", null)
        );
    }
}