package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Equipo;
import com.Fotocopiadoras.Fotocopiadoras.Service.EquipoService;

@RestController
@RequestMapping("/api/v1/equipo")
@CrossOrigin(origins = "*", maxAge = 3600)
public class EquipoRestController {
    @Autowired
    private EquipoService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Equipo>> registrar(@RequestBody Equipo e) {
        Equipo resultado = service.registrar(e);
        return new ResponseEntity<>(
            ApiResponse.success("Equipo registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Equipo>>> listar() {
        List<Equipo> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Equipos obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Equipo>> buscarPorId(@PathVariable Integer id) {
        Equipo resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Equipo obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Equipo>> actualizar(
            @PathVariable Integer id,
            @RequestBody Equipo e) {
        e.setId(id);
        Equipo resultado = service.actualizar(e);
        return ResponseEntity.ok(
            ApiResponse.success("Equipo actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Equipo eliminado exitosamente", null)
        );
    }
}