package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Personal;
import com.Fotocopiadoras.Fotocopiadoras.Service.PersonalService;

@RestController
@RequestMapping("/api/v1/personal")
@CrossOrigin(origins = "*", maxAge = 3600)
public class PersonalRestController {
    @Autowired
    private PersonalService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Personal>> registrar(@RequestBody Personal p) {
        Personal resultado = service.registrar(p);
        return new ResponseEntity<>(
            ApiResponse.success("Personal registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Personal>>> listar() {
        List<Personal> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Personal obtenido exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Personal>> buscarPorId(@PathVariable Integer id) {
        Personal resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Personal obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Personal>> actualizar(
            @PathVariable Integer id,
            @RequestBody Personal p) {
        p.setId(id);
        Personal resultado = service.actualizar(p);
        return ResponseEntity.ok(
            ApiResponse.success("Personal actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Personal eliminado exitosamente", null)
        );
    }
}