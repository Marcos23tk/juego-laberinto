package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.EstadoEquipo;
import com.Fotocopiadoras.Fotocopiadoras.Service.EstadoEquipoService;

@RestController
@RequestMapping("/api/v1/estado-equipo")
@CrossOrigin(origins = "*", maxAge = 3600)
public class EstadoEquipoRestController {
    @Autowired
    private EstadoEquipoService service;

    @PostMapping
    public ResponseEntity<ApiResponse<EstadoEquipo>> registrar(@RequestBody EstadoEquipo e) {
        EstadoEquipo resultado = service.registrar(e);
        return new ResponseEntity<>(
            ApiResponse.success("Estado de Equipo registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<EstadoEquipo>>> listar() {
        List<EstadoEquipo> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Estados de Equipo obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<EstadoEquipo>> buscarPorId(@PathVariable Integer id) {
        EstadoEquipo resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Estado de Equipo obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<EstadoEquipo>> actualizar(
            @PathVariable Integer id,
            @RequestBody EstadoEquipo e) {
        e.setId(id);
        EstadoEquipo resultado = service.actualizar(e);
        return ResponseEntity.ok(
            ApiResponse.success("Estado de Equipo actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Estado de Equipo eliminado exitosamente", null)
        );
    }
}