package com.Fotocopiadoras.Fotocopiadoras.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse {
    private String token;
    private String type = "Bearer";
    private Integer userId;
    private String username;
    private String nombre;
    private String rol;

    public LoginResponse(String token, Integer userId, String username, String nombre, String rol) {
        this.token = token;
        this.userId = userId;
        this.username = username;
        this.nombre = nombre;
        this.rol = rol;
    }
}
