package com.Fotocopiadoras.Fotocopiadoras;

import com.Fotocopiadoras.Fotocopiadoras.Config.AppProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(AppProperties.class)
public class FotocopiadorasApplication {

    public static void main(String[] args) {
        SpringApplication.run(FotocopiadorasApplication.class, args);
    }
}