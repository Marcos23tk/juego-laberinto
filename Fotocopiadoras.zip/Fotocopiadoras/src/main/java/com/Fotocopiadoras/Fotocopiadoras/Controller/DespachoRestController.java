package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Despacho;
import com.Fotocopiadoras.Fotocopiadoras.Service.DespachoService;

@RestController
@RequestMapping("/api/v1/despacho")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DespachoRestController {
    @Autowired
    private DespachoService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Despacho>> registrar(@RequestBody Despacho d) {
        Despacho resultado = service.registrar(d);
        return new ResponseEntity<>(
            ApiResponse.success("Despacho registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Despacho>>> listar() {
        List<Despacho> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Despachos obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Despacho>> buscarPorId(@PathVariable Integer id) {
        Despacho resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Despacho obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Despacho>> actualizar(
            @PathVariable Integer id,
            @RequestBody Despacho d) {
        d.setId(id);
        Despacho resultado = service.actualizar(d);
        return ResponseEntity.ok(
            ApiResponse.success("Despacho actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Despacho eliminado exitosamente", null)
        );
    }
}