package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Sede;
import com.Fotocopiadoras.Fotocopiadoras.Service.SedeService;

@RestController
@RequestMapping("/api/v1/sede")
@CrossOrigin(origins = "*", maxAge = 3600)
public class SedeRestController {
    @Autowired
    private SedeService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Sede>> registrar(@RequestBody Sede s) {
        Sede resultado = service.registrar(s);
        return new ResponseEntity<>(
            ApiResponse.success("Sede registrada exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Sede>>> listar() {
        List<Sede> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Sedes obtenidas exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Sede>> buscarPorId(@PathVariable Integer id) {
        Sede resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Sede obtenida exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Sede>> actualizar(
            @PathVariable Integer id,
            @RequestBody Sede s) {
        s.setId(id);
        Sede resultado = service.actualizar(s);
        return ResponseEntity.ok(
            ApiResponse.success("Sede actualizada exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Sede eliminada exitosamente", null)
        );
    }
}