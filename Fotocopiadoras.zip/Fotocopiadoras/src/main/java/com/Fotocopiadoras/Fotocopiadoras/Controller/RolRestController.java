package com.Fotocopiadoras.Fotocopiadoras.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Fotocopiadoras.Fotocopiadoras.Dto.ApiResponse;
import com.Fotocopiadoras.Fotocopiadoras.Entity.Rol;
import com.Fotocopiadoras.Fotocopiadoras.Service.RolService;

@RestController
@RequestMapping("/api/v1/rol")
@CrossOrigin(origins = "*", maxAge = 3600)
public class RolRestController {

    @Autowired
    private RolService service;

    @PostMapping
    public ResponseEntity<ApiResponse<Rol>> registrar(@RequestBody Rol r) {
        Rol resultado = service.registrar(r);
        return new ResponseEntity<>(
            ApiResponse.success("Rol registrado exitosamente", resultado),
            HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Rol>>> listar() {
        List<Rol> resultado = service.listar();
        return ResponseEntity.ok(
            ApiResponse.success("Roles obtenidos exitosamente", resultado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Rol>> buscarPorId(@PathVariable Integer id) {
        Rol resultado = service.buscarPorId(id);
        return ResponseEntity.ok(
            ApiResponse.success("Rol obtenido exitosamente", resultado)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Rol>> actualizar(
            @PathVariable Integer id,
            @RequestBody Rol r) {
        r.setId(id);
        Rol resultado = service.actualizar(r);
        return ResponseEntity.ok(
            ApiResponse.success("Rol actualizado exitosamente", resultado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok(
            ApiResponse.success("Rol eliminado exitosamente", null)
        );
    }
}