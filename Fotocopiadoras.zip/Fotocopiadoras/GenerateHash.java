import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class GenerateHash {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String password = "soyelputoamo23";
        String hash = encoder.encode(password);
        System.out.println("Hash BCrypt: " + hash);
    }
}
